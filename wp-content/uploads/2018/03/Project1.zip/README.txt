collectingTweets.py is the code that gets the twitter data
ScrapeUSHappiestStates.py is the code that scrapes the table from the website
tweets_cleaning.py is the code that cleans the tweets
HappiestStatesDataCleaning.py is the code that checks and cleans the states table
Csv files are the datasets
ANLY Project 1 Write-up is the write-up word doc. 
After_Clean_tweets.csv is the csv that includes all the data after cleaning
statesAfterCleaning.csv is the happiest states data after cleaning
