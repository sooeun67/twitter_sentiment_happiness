import pandas as pd
import numpy as np

# =================================================================================
# Since the data is tweets, the only thing we can check is the missing values
# The function below checks for the missing values of a column and returns a score that represents the level of cleanliness
# 100 being the best and 0 being the worst
def checkCleanliness(df_col, row_count):
    score = 100
    missing_values_counts = df_col.isnull().sum()
    score = score *(1-missing_values_counts/row_count)
    return score

# =================================================================================
# Read in the data
print('Reading in the data ....')
before_columns=['tweet_date', 'tweet_id', 'raw_text', 'hashtags', 'symbols', 'result_type', 'language',
                           'user_id', 'user_location',
                           'user_name', 'user_screen_name', 'user_description', 'followers_count', 'friends_count',
                           'time_zone', 'location_id', 'location_type', 'location_name', 'location_country',
                           'retweeted', 'retweet_count', 'fav_count']

df25 = pd.read_csv('Tweets_09_25.csv')
df26 = pd.read_csv('Tweets_09_26.csv')
df27 = pd.read_csv('Tweets_09_27.csv')
df28 = pd.read_csv('Tweets_09_28.csv')
df29 = pd.read_csv('Tweets_09_29.csv')
df30 = pd.read_csv('Tweets_09_30.csv')
df01 = pd.read_csv('Tweets_10_01.csv')
df02 = pd.read_csv('Tweets_10_02.csv')
df03 = pd.read_csv('Tweets_10_03.csv')
df04 = pd.read_csv('Tweets_10_04.csv')
df051 = pd.read_csv('Tweets_10_05_01.csv')
df052 = pd.read_csv('Tweets_10_05_02.csv')
dfp = pd.read_csv('Tweets_popular.csv')

# concatenate all the data together to perform data cleaning
df25 = pd.concat([df25, df26, df27, df28, df29, df30, df01, df02, df03, df04, df051, df052, dfp], axis=0, ignore_index=True)

# Write the before-cleaning data to a csv file
# df25.to_csv('Pre_clean_tweets.csv')

#
del df25['Unnamed: 0']
df25.loc[df25['hashtags']=='[]', 'hashtags'] = np.nan
df25.loc[df25['symbols']=='[]', 'symbols'] = np.nan

# ==============================================================
# Check the score of each attribute before cleaning
print('checking the data...')
for col in before_columns:
    print('Score of each attribute before cleaning: ')
    score = checkCleanliness(df25[col], 87082)
    print('The Cleanliness of', col, 'is:', score)


# Drop empty rows
# print(df25[df25['tweet_date'].isnull()])
df25 = df25.drop(df25.index[[61407, 70580]])

# ===============================================================
# clean the tweet date, convert into easy to read format
# Some tweets are not recorded properly, we dropped these rows
# print(df25.iloc[[27311, 28491, 30103, 39524, 49137, 61407, 70581]])
df25 = df25.drop(df25.index[[27311, 28491, 30103, 39524, 49137, 61407]])
df25['tweet_month'] = (df25['tweet_date'].str.split().str.get(1))
df25['tweet_day'] = (df25['tweet_date'].str.split().str.get(2))
df25['tweet_year'] = (df25['tweet_date'].str.split().str.get(5))
df25['tweet_date'] = df25['tweet_year'] +'-'+df25['tweet_month'] + '-' + df25['tweet_day']
del df25['tweet_month']
del df25['tweet_year']
del df25['tweet_day']
df25 = df25[df25['tweet_date'].notnull()]

# ==============================================================
# Fix bad record
# Some rows have bad/empty entries, we need to remove those
# print(df25[df25['language'].isnull()])
df25 = df25[df25['language'].notnull()]
# print(df25[df25['user_name'].isnull()])
df25.loc[df25['user_name'].isnull(), 'user_name'] = 'name'
# print(df25[df25['followers_count'].isnull()])
df25 = df25[df25['followers_count'].notnull()]

# ===============================================================
# Convert hashtag column to 0/1: no hastag = 0, with hastag = 1
df25.loc[df25['hashtags'].notnull() , 'hashtags'] = 1
df25.loc[df25['hashtags'].isnull(), 'hashtags'] = 0

# Drop column symbol because there are way too many missing values
del df25['symbols']

# ================================================================
# Deal with missing users' locations (some users did not enter location into their porfiles)
# Compare to the auto-detected locations

# print(df25[['user_location', 'location_name']])

# It looks like the auto-detected locations are really accurate and organized
# Sometime people move around but most of time would be within the same state
# we will just use the auto-detected location
del df25['user_location']



# ================================================================
# Missing values of user's description = No description

# print(df25['user_description'])
df25.loc[df25['user_description'].isnull(), 'user_description'] = 'No Description'

# ================================================================
# Missing value of timezone
# print(df25.loc[df25['time_zone'].isnull(), 'location_name'])



# =================================================================
# Seperate the state name out from the location_name
# The formats of location_name are different, so we need to refer to location_type in order to succussfully extract the state
# print(df25['location_type'].unique())

# When location_type == 'city'
# print(df25.loc[df25['location_type']=='city', 'location_name'])
df25['state_name'] = ((df25.loc[df25['location_type']=='city', 'location_name']).str.split(', ').str.get(1))

# When location_type = 'admin'
# print(df25.loc[df25['location_type']=='admin', 'location_name'])
df25.loc[df25['location_type']=='admin', 'state_name'] = ((df25.loc[df25['location_type']=='admin', 'location_name']).str.split(', ').str.get(0)).dropna()

# Drop the rows When location_type = 'poi' and 'country' and 'neighborhood' because they are really hard to determine the state
# print(df25.loc[df25['location_type']=='poi', 'user_location'])
# print(df25.loc[df25['location_type']=='neighborhood', 'location_name'])
# print(df25.loc[df25['location_type']=='country', 'location_name'])
df25 = df25[df25['location_type'] != 'poi']
df25 = df25[df25['location_type'] != 'neighborhood']
df25 = df25[df25['location_type'] != 'country']

# Some states have full names, so we need convert all of them to abbreviations
# and some entries have bad input, we need to remove them
# print(df25['state_name'])
us_state_abbrev = {
    'Alabama': 'AL',
    'Alaska': 'AK',
    'Arizona': 'AZ',
    'Arkansas': 'AR',
    'California': 'CA',
    'Colorado': 'CO',
    'Connecticut': 'CT',
    'Delaware': 'DE',
    'Florida': 'FL',
    'Georgia': 'GA',
    'Hawaii': 'HI',
    'Idaho': 'ID',
    'Illinois': 'IL',
    'Indiana': 'IN',
    'Iowa': 'IA',
    'Kansas': 'KS',
    'Kentucky': 'KY',
    'Louisiana': 'LA',
    'Maine': 'ME',
    'Maryland': 'MD',
    'Massachusetts': 'MA',
    'Michigan': 'MI',
    'Minnesota': 'MN',
    'Mississippi': 'MS',
    'Missouri': 'MO',
    'Montana': 'MT',
    'Nebraska': 'NE',
    'Nevada': 'NV',
    'New Hampshire': 'NH',
    'New Jersey': 'NJ',
    'New Mexico': 'NM',
    'New York': 'NY',
    'North Carolina': 'NC',
    'North Dakota': 'ND',
    'Ohio': 'OH',
    'Oklahoma': 'OK',
    'Oregon': 'OR',
    'Pennsylvania': 'PA',
    'Rhode Island': 'RI',
    'South Carolina': 'SC',
    'South Dakota': 'SD',
    'Tennessee': 'TN',
    'Texas': 'TX',
    'Utah': 'UT',
    'Vermont': 'VT',
    'Virginia': 'VA',
    'Washington': 'WA',
    'West Virginia': 'WV',
    'Wisconsin': 'WI',
    'Wyoming': 'WY',
    'San Francisco-Oakland-San Jose CA': 'CA',
    'Atlanta GA': 'GA', 'Madison WI': 'WI',
    'Philadelphia PA': 'PA', 'Puerto Rico': 'PURI',
    'Virgin Islands': 'VI', 'Springfield MO': 'MO',
    'Lexington KY': 'KY', 'Spokane WA': 'WA', 'Dallas-Fort Worth TX': 'TX',
    'Pittsburgh PA': 'PA', 'Greensboro-High Point-Winston Salem NC': 'NC',
    'Miami-Fort Lauderdale FL': 'FL', 'Columbus OH': 'OH', 'Detroit MI': 'MI',
    'South Bend-Elkhart IN': 'IN', 'Milwaukee WI': 'WI', 'Richmond-Petersburg VA': 'VA',
    'Shreveport LA': 'LA', 'Toledo OH': 'OH', 'District of Columbia': 'DC',
    'Providence RI-New Bedford MA': 'MA', 'New York NY': 'NY', 'Denver CO': 'CO',
    'Tucson AZ': 'AZ', 'Greenville-New Bern-Washington NC': 'NC', 'Harrisburg-Lancaster-Lebanon-York PA': 'PA',
    'Louisville KY': 'KY', 'Hartford & New Haven CT': 'CT'
}

# get the rows where state_name is not abbreviations
# convert them by using mapping
full_name = (df25.loc[df25['state_name'].str.len() >2, 'state_name'])
abv_name = full_name.map(us_state_abbrev)
df25 = df25[df25['state_name'] != 'USA']
df25.loc[df25['state_name'].str.len() >2, 'state_name'] = abv_name

# =========================================================
after_columns=['tweet_date', 'tweet_id', 'raw_text', 'hashtags', 'result_type', 'language',
                           'user_id',
                           'user_name', 'user_screen_name', 'user_description', 'followers_count', 'friends_count',
                           'time_zone', 'location_id', 'location_type', 'location_name', 'location_country',
                           'retweeted', 'retweet_count', 'fav_count', 'state_name']

# ==========================================================
# Drop web links, picture links, and @users in twitter text
# Drop web links
df25['raw_text'] = df25['raw_text'].replace(r'http\S+', '', regex=True)
# Drop @users
df25['raw_text'] = df25['raw_text'].replace('@[A-Za-z0-9]+', '', regex=True)
# remove just the hash #
df25['raw_text'] = df25['raw_text'].replace('#', '', regex=True)
# Convert text to all lowercase
df25['raw_text'] = df25['raw_text'].str.lower()
# Remove Question marks, since a lot of questions marks are emojis that did not convert right
df25['raw_text'] = df25['raw_text'].str.replace('?', '')
# ==========================================================
# Assigning all the tweets that are in DC to Maryland
df25.loc[df25['state_name'] == 'DC', 'state_name'] = 'MD'
# The Happiest states in US dataset does not have information for Puerto Rico, DC, and Virgin Islands
# So we need to drop the rows that have locations in these areas

df25 = df25[df25['state_name']!='VI']
df25 = df25[df25['state_name']!='PURI']


print()
print()
print('Finished cleaning....')
print()
print('Score of each attribute after cleaning: ')

for col in after_columns:
    print('Score of each attribute before cleaning: ')
    score = checkCleanliness(df25[col], 84377)
    print('The Cleanliness of', col, 'is:', score)




# Write the data to a csv file
# df25.to_csv('After_clean_tweets.csv')

# Check the Distributions of States
df25['state_name'].value_counts().plot(kind='bar', title = 'Number of Tweets by States')

# Check if there is any spamming issues with the tweets
# The following prints out the top 10 users by number of tweets in 10 days
print(df25['user_id'].value_counts().head(10))