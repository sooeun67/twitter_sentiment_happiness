import tweepy
from tweepy import OAuthHandler
import pandas as pd
import numpy as np

# Twitter authorization
consumer_key = 'wihjUwZ8oJo4rabbyjttw8bJn'
consumer_secret = '2zsgKeDWfRGDoMk4aCkpMY8mOB9NglEVlZzOiVDGsim77y6pXG'
access_token = '894230082411053057-fz46GNezU7RjxkWdvfpExKsFpQjvyPV'
access_secret = 'pSZPPGjPYS1n8V430QP0XTC4pKT0HHR69SMdCyGg96XLR'

auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)

api = tweepy.API(auth)

# Use API Search and Cursor to get tweets, change parameters to restrict tweets to english and in USA
results = tweepy.Cursor(api.search, q='place:96683cc9126741d1', lang='en', result_type='rencent', until = '2017-10-06',count=100).items(8000)
places = api.geo_search(query="USA", granularity="country")
place_id = (places[0].id)

# Extract all useful information and put them into a dataframe
datas = []
for result in results:
    tweet_date = result._json['created_at']
    tweet_id = result._json['id']
    text = result._json['text']
    hashtags = result._json['entities']['hashtags']
    if hashtags != []:
        hashtags = result._json['entities']['hashtags'][0]['text']
    symbols = result._json['entities']['symbols']
    result_type = result._json['metadata']['result_type']
    language = result._json['metadata']['iso_language_code']
    user_id = result._json['user']['id']
    user_location = result._json['user']['location']
    user_name = result._json['user']['name']
    user_screen_name = result._json['user']['screen_name']
    user_description = result._json['user']['description']
    followers = result._json['user']['followers_count']
    friends = result._json['user']['friends_count']
    time_zone = result._json['user']['time_zone']
    location_id = result._json['place']['id']
    location_type = result._json['place']['place_type']
    location_name = result._json['place']['full_name']
    location_country = result._json['place']['country_code']
    retweeted = result._json['retweeted']
    retweet_count = result._json['retweet_count']
    fav_count = result._json['favorite_count']
    row = [tweet_date, tweet_id, text, hashtags, symbols, result_type, language, user_id, user_location, user_name,
           user_screen_name, user_description, followers, friends, time_zone, location_id, location_type, location_name,
           location_country, retweeted, retweet_count, fav_count]
    datas.append(row)
    # print(result._json['user'])

df = pd.DataFrame(data=datas,
                  columns=['tweet_date', 'tweet_id', 'raw_text', 'hashtags', 'symbols', 'result_type', 'language',
                           'user_id', 'user_location',
                           'user_name', 'user_screen_name', 'user_description', 'followers_count', 'friends_count',
                           'time_zone', 'location_id', 'location_type', 'location_name', 'location_country',
                           'retweeted', 'retweet_count', 'fav_count'])

print(df.head())

df.to_csv('tweets_10_05_02.csv')