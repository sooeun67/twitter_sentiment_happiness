import pandas as pd
import numpy as np



"""
Cleaning the State Happiness Data
"""
# =================================================================================
# Check the missing values/bad record or entries
# The function below checks for the missing values of a column and returns a score
def checkCleanliness(df_col, row_count):
    score = 100
    missing_values_counts = df_col.isnull().sum()
    score = score *(1-missing_values_counts/row_count)
    return score

# =================================================================================
# Read in the State Happiness data
print('Reading the data ....')
col_names = ['Rank', 'State', 'Score', 'Emotional/Phsycical_Wellbeing', 'WorkEnvironment', 'CommunityEnvoronment']

dfsh = pd.read_csv('HappiestStates.csv')

del dfsh['Unnamed: 0']


# =================================================================================
# Confirm values for ‘Rank’, ‘Emotional and Physical Well-Being’, ‘Work Environment’, and ‘Community Environment’ are valid - between 1 and 50, with no duplicates per column
print()
print('The descriptive summary of each attribute: ')
print(dfsh['Rank'].describe())
print(dfsh['Emotional/Phsycical_Wellbeing'].describe())
print(dfsh['CommunityEnvoronment'].describe())
print(dfsh['WorkEnvironment'].describe())



# =================================================================================
# Confirm that states are all valid states, no duplicates, no state abbreviations

# Some states have full names, so we need convert all of them to abbreviations
# and some entries have bad input, we need to remove them
# print(dfsh['State'])
us_state_abbrev = {
    'Alabama': 'AL',
    'Alaska': 'AK',
    'Arizona': 'AZ',
    'Arkansas': 'AR',
    'California': 'CA',
    'Colorado': 'CO',
    'Connecticut': 'CT',
    'Delaware': 'DE',
    'Florida': 'FL',
    'Georgia': 'GA',
    'Hawaii': 'HI',
    'Idaho': 'ID',
    'Illinois': 'IL',
    'Indiana': 'IN',
    'Iowa': 'IA',
    'Kansas': 'KS',
    'Kentucky': 'KY',
    'Louisiana': 'LA',
    'Maine': 'ME',
    'Maryland': 'MD',
    'Massachusetts': 'MA',
    'Michigan': 'MI',
    'Minnesota': 'MN',
    'Mississippi': 'MS',
    'Missouri': 'MO',
    'Montana': 'MT',
    'Nebraska': 'NE',
    'Nevada': 'NV',
    'New Hampshire': 'NH',
    'New Jersey': 'NJ',
    'New Mexico': 'NM',
    'New York': 'NY',
    'North Carolina': 'NC',
    'North Dakota': 'ND',
    'Ohio': 'OH',
    'Oklahoma': 'OK',
    'Oregon': 'OR',
    'Pennsylvania': 'PA',
    'Rhode Island': 'RI',
    'South Carolina': 'SC',
    'South Dakota': 'SD',
    'Tennessee': 'TN',
    'Texas': 'TX',
    'Utah': 'UT',
    'Vermont': 'VT',
    'Virginia': 'VA',
    'Washington': 'WA',
    'West Virginia': 'WV',
    'Wisconsin': 'WI',
    'Wyoming': 'WY',
}

# Convert State full names to abbreviations
# convert them by using mapping
dfsh['State'] = dfsh['State'].map(us_state_abbrev)


# =================================================================================
# Check the missing values score

print()
print('Score of each attribut: ')
for col in col_names:
    print('The Score of:', col, 'is:', checkCleanliness(dfsh[col], 50))
