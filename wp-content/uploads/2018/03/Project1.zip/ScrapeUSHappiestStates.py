import requests
from bs4 import BeautifulSoup
import pandas as pd

# Use requests to get the html of the web page
url = 'https://wallethub.com/edu/happiest-states/6959/'
request = requests.get(url)

# Use beautiful soup to parse the html and extract the table
soup = BeautifulSoup(request.text, 'html.parser')
table = soup.find('tbody')

# Loop through the parsed data and get the numbers
# put the data as an array
rows = table.find_all('tr')
datas = []
for row in rows:
    col = row.find_all('td')
    col0 = col[0].text.strip()
    col1 = col[1].text.strip()
    col2 = col[2].text.strip()
    col3 = col[3].text.strip()
    col4 = col[4].text.strip()
    col5 = col[5].text.strip()
    datas.append([col0, col1, col2, col3, col4, col5])

# Create the dataframe, put the data in, assign appropiate column names
df = pd.DataFrame(data=datas, columns=['Rank', 'State', 'Score', 'Emotional/Phsycical_Wellbeing', 'WorkEnvironment',
                                       'CommunityEnvoronment'])

# Write the dataframe to a csv
df.to_csv('HappiestStates.csv')